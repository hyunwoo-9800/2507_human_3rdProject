-- TB_PRODUCT_BUY CREATE
CREATE TABLE TB_PRODUCT_BUY (
    BUY_ID             VARCHAR2(36) PRIMARY KEY NOT NULL,       -- 즉시 구매 고유 ID
    ORDER_NUMBER       VARCHAR2(20) NOT NULL,                   -- 주문 번호
    PRODUCT_ID         VARCHAR2(36) NOT NULL,                   -- 상품 ID
    MEMBER_ID          VARCHAR2(36) NOT NULL,                   -- 구매자 ID
    BUY_QTY            NUMBER(8, 0) DEFAULT 1 NOT NULL,         -- 구매 수량
    BUY_UNIT_PRICE     NUMBER(10, 2) DEFAULT 1 NOT NULL,        -- 단가 (1kg 기준)
    BUY_TOTAL_PRICE    NUMBER(12, 2) NOT NULL,                  -- 총 구매 금액
    BUY_DELIVERY_DATE  DATE,                                    -- 배송 예정일
    CREATED_ID         VARCHAR2(36),                            -- 등록자 ID
    CREATED_DATE       DATE DEFAULT SYSDATE,                   -- 등록일시
    UPDATED_ID         VARCHAR2(36),                            -- 수정자 ID
    UPDATED_DATE       DATE DEFAULT SYSDATE                    -- 수정일시
);


-- 테이블 코멘트
COMMENT ON TABLE TB_PRODUCT_BUY IS '상품 즉시 구매 테이블';


-- 컬럼 코멘트
COMMENT ON COLUMN TB_PRODUCT_BUY.BUY_ID IS '즉시 구매 고유 ID (UUID)';
COMMENT ON COLUMN TB_PRODUCT_BUY.ORDER_NUMBER IS '주문번호';
COMMENT ON COLUMN TB_PRODUCT_BUY.PRODUCT_ID IS '상품 ID (TB_PRODUCT.PRODUCT_ID 참조)';
COMMENT ON COLUMN TB_PRODUCT_BUY.MEMBER_ID IS '구매자 회원 ID (TB_MEMBER.MEMBER_ID 참조)';
COMMENT ON COLUMN TB_PRODUCT_BUY.BUY_QTY IS '구매 수량';
COMMENT ON COLUMN TB_PRODUCT_BUY.BUY_UNIT_PRICE IS '1kg 단가 (구매 시점 기준)';
COMMENT ON COLUMN TB_PRODUCT_BUY.BUY_TOTAL_PRICE IS '총 구매 금액 (수량 × 단가)';
COMMENT ON COLUMN TB_PRODUCT_BUY.BUY_DELIVERY_DATE IS '배송 예정일';
COMMENT ON COLUMN TB_PRODUCT_BUY.CREATED_ID IS '등록자 ID (로그인 사용자 ID)';
COMMENT ON COLUMN TB_PRODUCT_BUY.CREATED_DATE IS '등록일시 (기본값 SYSDATE)';
COMMENT ON COLUMN TB_PRODUCT_BUY.UPDATED_ID IS '수정자 ID (로그인 사용자 ID)';
COMMENT ON COLUMN TB_PRODUCT_BUY.UPDATED_DATE IS '수정일시 (기본값 SYSDATE)';
