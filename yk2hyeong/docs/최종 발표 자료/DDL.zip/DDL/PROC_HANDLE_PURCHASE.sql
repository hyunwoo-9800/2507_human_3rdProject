CREATE OR REPLACE PROCEDURE PROC_HANDLE_PURCHASE (
    P_ORDER_TYPE       IN VARCHAR2,
    P_ORDER_NUMBER     IN VARCHAR2,
    P_PRODUCT_ID       IN VARCHAR2,
    P_MEMBER_ID        IN VARCHAR2,
    P_QTY              IN NUMBER,
    P_UNIT_PRICE       IN NUMBER,
    P_TOTAL_PRICE      IN NUMBER,
    P_DELIVERY_DATE    IN DATE,
    P_CREATED_ID       IN VARCHAR2
)
IS
    V_SELLER_ID TB_PRODUCT.SELL_MEMBER_ID%TYPE;
BEGIN

-- 즉시 구매 시
    IF P_ORDER_TYPE = 'immediate' THEN
    -- 1. 구매내역 저장
    INSERT INTO TB_PURCHASE (
        PURCHASE_ID, MEMBER_ID, PRODUCT_ID,
        PURCHASE_QTY, UNIT_PRICE, TOTAL_PRICE,
        PURCHASE_DATE, PURCHASE_STATUS,
        CREATED_ID, CREATED_DATE, UPDATED_ID, UPDATED_DATE
    ) VALUES (
        SYS_GUID(), P_MEMBER_ID, P_PRODUCT_ID,
        P_QTY, P_UNIT_PRICE, P_TOTAL_PRICE,
        SYSDATE,
        (
            SELECT
                A.DETAIL_CODE_ID
            FROM
                TB_CODE_DETAIL A
                LEFT JOIN TB_CODE B
                ON A.CODE_ID = B.CODE_ID
            WHERE
                    B.TOP_CODE_NAME = 'STATUS'
                AND A.LOW_CODE_VALUE = '007'
        ),
        P_CREATED_ID, SYSDATE, P_CREATED_ID, SYSDATE
    );

    -- 2. 주문정보 저장
    INSERT INTO TB_PRODUCT_BUY (
        BUY_ID, ORDER_NUMBER, PRODUCT_ID, MEMBER_ID,
        BUY_QTY, BUY_UNIT_PRICE, BUY_TOTAL_PRICE, BUY_DELIVERY_DATE,
        CREATED_ID, CREATED_DATE, UPDATED_ID, UPDATED_DATE
    ) VALUES (
        SYS_GUID(), P_ORDER_NUMBER, P_PRODUCT_ID, P_MEMBER_ID,
        P_QTY, P_UNIT_PRICE, P_TOTAL_PRICE, P_DELIVERY_DATE,
        P_CREATED_ID, SYSDATE, P_CREATED_ID, SYSDATE
    );

    -- 3. 상품 재고 차감
    UPDATE TB_PRODUCT
    SET PRODUCT_STOCK_QTY = PRODUCT_STOCK_QTY - P_QTY
    WHERE PRODUCT_ID = P_PRODUCT_ID;

    -- 4. 구매자 알림
    INSERT INTO TB_ALARM (
        ALARM_ID, ALARM_TYPE, ALARM_CONTENT,
        RECEIVER_ID, PRODUCT_ID, IS_READ,
        CREATED_ID, CREATED_DATE, UPDATED_ID, UPDATED_DATE
    ) VALUES (
        SYS_GUID(),
        (
            SELECT
                A.DETAIL_CODE_ID
            FROM
                TB_CODE_DETAIL A
                LEFT JOIN TB_CODE B
                ON A.CODE_ID = B.CODE_ID
            WHERE
                    B.TOP_CODE_NAME = 'STATUS'
                AND A.LOW_CODE_VALUE = '007'
        ),
        '구매가 완료되었습니다.',
        P_MEMBER_ID, P_PRODUCT_ID, 'N',
        P_CREATED_ID, SYSDATE, P_CREATED_ID, SYSDATE
    );

    -- 5. 판매자 알림
    SELECT SELL_MEMBER_ID INTO V_SELLER_ID
    FROM TB_PRODUCT
    WHERE PRODUCT_ID = P_PRODUCT_ID;

    INSERT INTO TB_ALARM (
        ALARM_ID, ALARM_TYPE, ALARM_CONTENT,
        RECEIVER_ID, PRODUCT_ID, IS_READ,
        CREATED_ID, CREATED_DATE, UPDATED_ID, UPDATED_DATE
    ) VALUES (
        SYS_GUID(),
        (
            SELECT
                A.DETAIL_CODE_ID
            FROM
                TB_CODE_DETAIL A
                LEFT JOIN TB_CODE B
                ON A.CODE_ID = B.CODE_ID
            WHERE
                    B.TOP_CODE_NAME = 'STATUS'
                AND A.LOW_CODE_VALUE = '008'
        ),
        '상품이 판매되었습니다.',
        V_SELLER_ID, P_PRODUCT_ID, 'N',
        P_CREATED_ID, SYSDATE, P_CREATED_ID, SYSDATE
    );
ELSE
-- 예약 구매 시
    -- 1. 구매내역 저장
    INSERT INTO TB_PURCHASE (
        PURCHASE_ID, MEMBER_ID, PRODUCT_ID,
        PURCHASE_QTY, UNIT_PRICE, TOTAL_PRICE,
        PURCHASE_DATE, PURCHASE_STATUS,
        CREATED_ID, CREATED_DATE, UPDATED_ID, UPDATED_DATE
    ) VALUES (
        SYS_GUID(), P_MEMBER_ID, P_PRODUCT_ID,
        P_QTY, P_UNIT_PRICE, P_TOTAL_PRICE,
        SYSDATE,
        (
            SELECT
                A.DETAIL_CODE_ID
            FROM
                TB_CODE_DETAIL A
                LEFT JOIN TB_CODE B
                ON A.CODE_ID = B.CODE_ID
            WHERE
                    B.TOP_CODE_NAME = 'STATUS'
                AND A.LOW_CODE_VALUE = '007'
        ),
        P_CREATED_ID, SYSDATE, P_CREATED_ID, SYSDATE
    );

    -- 2. 주문정보 저장
    INSERT INTO TB_PRODUCT_RESERVATION (
        REV_ID, ORDER_NUMBER, PRODUCT_ID, MEMBER_ID,
        REV_DATE, REV_QTY, REV_UNIT_PRICE, REV_TOTAL_PRICE,
        REV_DELIVERY_DATE, REV_STATUS,
        CREATED_ID, CREATED_DATE, UPDATED_ID, UPDATED_DATE
    ) VALUES (
        SYS_GUID(), P_ORDER_NUMBER, P_PRODUCT_ID, P_MEMBER_ID,
        SYSDATE, P_QTY, P_UNIT_PRICE, P_TOTAL_PRICE,
        P_DELIVERY_DATE,
        (
            SELECT
                A.DETAIL_CODE_ID
            FROM
                TB_CODE_DETAIL A
                LEFT JOIN TB_CODE B
                ON A.CODE_ID = B.CODE_ID
            WHERE
                B.TOP_CODE_NAME = 'REV_STATUS'
            AND A.LOW_CODE_VALUE = '001'
        ),
        P_CREATED_ID, SYSDATE, P_CREATED_ID, SYSDATE
    );

    -- 3. 상품 재고 차감
    UPDATE TB_PRODUCT
    SET PRODUCT_STOCK_QTY = PRODUCT_STOCK_QTY - P_QTY
    WHERE PRODUCT_ID = P_PRODUCT_ID;

    -- 4. 구매자 알림
    INSERT INTO TB_ALARM (
        ALARM_ID, ALARM_TYPE, ALARM_CONTENT,
        RECEIVER_ID, PRODUCT_ID, IS_READ,
        CREATED_ID, CREATED_DATE, UPDATED_ID, UPDATED_DATE
    ) VALUES (
        SYS_GUID(),
        (
            SELECT
                A.DETAIL_CODE_ID
            FROM
                TB_CODE_DETAIL A
                LEFT JOIN TB_CODE B
                ON A.CODE_ID = B.CODE_ID
            WHERE
                    B.TOP_CODE_NAME = 'REV_STATUS'
                AND A.LOW_CODE_VALUE = '001'
        ),
        '예약이 완료되었습니다.',
        P_MEMBER_ID, P_PRODUCT_ID, 'N',
        P_CREATED_ID, SYSDATE, P_CREATED_ID, SYSDATE
    );

    -- 5. 판매자 알림
    SELECT SELL_MEMBER_ID INTO V_SELLER_ID
    FROM TB_PRODUCT
    WHERE PRODUCT_ID = P_PRODUCT_ID;

    INSERT INTO TB_ALARM (
        ALARM_ID, ALARM_TYPE, ALARM_CONTENT,
        RECEIVER_ID, PRODUCT_ID, IS_READ,
        CREATED_ID, CREATED_DATE, UPDATED_ID, UPDATED_DATE
    ) VALUES (
        SYS_GUID(),
        (
            SELECT
                A.DETAIL_CODE_ID
            FROM
                TB_CODE_DETAIL A
                LEFT JOIN TB_CODE B
                ON A.CODE_ID = B.CODE_ID
            WHERE
                    B.TOP_CODE_NAME = 'REV_STATUS'
                AND A.LOW_CODE_VALUE = '001'
        ),
        '상품이 예약판매되었습니다.',
        V_SELLER_ID, P_PRODUCT_ID, 'N',
        P_CREATED_ID, SYSDATE, P_CREATED_ID, SYSDATE
    );
END IF;
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
        
END;
