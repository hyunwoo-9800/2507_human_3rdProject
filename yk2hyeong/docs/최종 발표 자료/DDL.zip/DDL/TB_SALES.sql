-- TB_SALES CREATE
CREATE TABLE TB_SALES (
    HISTORY_PRICE_ID     VARCHAR2(36) PRIMARY KEY NOT NULL,  -- 판매 기록 ID
    PRODUCT_ID           VARCHAR2(36) NOT NULL,              -- 상품 ID
    MEMBER_ID            VARCHAR2(36) NOT NULL,              -- 주문자 ID
    SALES_DATE           DATE NOT NULL,                      -- 판매 일자
    SALES_PRICE          NUMBER(12, 0) NOT NULL,             -- 판매 가격
    SALES_UNIT           NUMBER(8, 0) NOT NULL,              -- 판매 단위 (팔린 수량)
    SALES_UNIT_PRICE     NUMBER(10, 2) NOT NULL,             -- kg당 단가
    CREATED_ID           VARCHAR2(36),                       -- 등록자 ID
    CREATED_DATE         DATE DEFAULT SYSDATE,               -- 등록일시
    UPDATED_ID           VARCHAR2(36),                       -- 수정자 ID
    UPDATED_DATE         DATE DEFAULT SYSDATE                -- 수정일시
);

-- 테이블 코멘트
COMMENT ON TABLE TB_SALES IS '실제 판매 데이터 테이블';

-- 컬럼 코멘트
COMMENT ON COLUMN TB_SALES.HISTORY_PRICE_ID IS '판매 이력 고유 ID (UUID)';
COMMENT ON COLUMN TB_SALES.PRODUCT_ID IS '상품 ID (판매된 상품)';
COMMENT ON COLUMN TB_SALES.MEMBER_ID IS '주문자 회원 ID';
COMMENT ON COLUMN TB_SALES.SALES_DATE IS '판매 일자 (형식: YYYY-MM-DD)';
COMMENT ON COLUMN TB_SALES.SALES_PRICE IS '판매 가격 (총 판매 금액)';
COMMENT ON COLUMN TB_SALES.SALES_UNIT IS '판매 단위 (팔린 수량)';
COMMENT ON COLUMN TB_SALES.SALES_UNIT_PRICE IS 'kg당 단가 (원/1kg)';
COMMENT ON COLUMN TB_SALES.CREATED_ID IS '등록자 ID (로그인 사용자 ID)';
COMMENT ON COLUMN TB_SALES.CREATED_DATE IS '등록일시 (기본값 SYSDATE)';
COMMENT ON COLUMN TB_SALES.UPDATED_ID IS '수정자 ID (로그인 사용자 ID)';
COMMENT ON COLUMN TB_SALES.UPDATED_DATE IS '수정일시 (기본값 SYSDATE)';
